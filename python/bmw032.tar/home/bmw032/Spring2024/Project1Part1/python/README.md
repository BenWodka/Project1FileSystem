Example code to read from fixed length records (random access file)
Author:  Susan Gauch, Thanh Bui

To run the example on turing:
python3 TestDB.py
